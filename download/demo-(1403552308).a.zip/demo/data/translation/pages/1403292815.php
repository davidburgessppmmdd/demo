<?php 
// Translation strings
__('Google Maps', 'framework');
__('New Tab', 'framework');
__('Google Map Information', 'framework');
__('Show Google Maps?', 'framework');
__('Google Maps API Key', 'framework');
?>