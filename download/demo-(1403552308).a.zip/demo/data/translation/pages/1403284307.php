<?php 
// Translation strings
__('Contact Info', 'framework');
__('Business Type', 'framework');
__('Company Name', 'framework');
__('Phone Numbers', 'framework');
__('Phone Number', 'framework');
__('Toll Free', 'framework');
__('Address', 'framework');
__('Address Line 1', 'framework');
__('Address Line 2', 'framework');
__('City', 'framework');
__('State', 'framework');
__('Zip Code', 'framework');
__('Email', 'framework');
__('Email Address', 'framework');
__('Email Address Text', 'framework');
__('Use this shortcode to display an email link [email]', 'framework');
__('This will be the link text displayed for your email address', 'framework');
?>