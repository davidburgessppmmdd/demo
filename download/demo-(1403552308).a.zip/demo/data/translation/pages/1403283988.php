<?php 
// Translation strings
__('Theme Options', 'framework');
__('Logos', 'framework');
__('New Container | invisible', 'framework');
__('Header Logo', 'framework');
__('Footer Logo', 'framework');
?>