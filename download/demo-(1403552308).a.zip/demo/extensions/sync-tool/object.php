<?php
class Sync_Tool_Object extends Runway_Object {

	public function __construct( $settings ) {

		parent::__construct( $settings );

	}

}
?>
