<?php

class Theme_Updater_Object extends Runway_Object {

} 
?>