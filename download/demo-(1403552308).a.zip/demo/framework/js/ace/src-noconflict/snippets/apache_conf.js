ace.define('ace/snippets/apache_conf', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "apache_conf";

});
