ace.define('ace/snippets/sass', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "sass";

});
