ace.define('ace/snippets/c9search', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "c9search";

});
