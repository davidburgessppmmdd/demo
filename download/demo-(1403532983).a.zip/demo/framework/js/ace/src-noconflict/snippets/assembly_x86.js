ace.define('ace/snippets/assembly_x86', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "assembly_x86";

});
