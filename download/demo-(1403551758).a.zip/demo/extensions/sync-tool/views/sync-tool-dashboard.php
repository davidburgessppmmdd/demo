<div class="meta-box-sortables metabox-holder">
	<div class="postbox">
		<div class="handlediv" title="<?php echo __('Click to toggle', 'framework'); ?>"><br></div>
		<h3 class="hndle"><span><?php echo __('Access key', 'framework'); ?></span></h3>
		<div class="inside">
			<span><?php echo __('Access key', 'framework'); ?>: <?php echo $sync_tool_admin->get_key(); ?></span>			
		</div>
	</div>
</div>