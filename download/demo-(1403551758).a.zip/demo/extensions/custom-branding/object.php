<?php

class Custom_Branding_Settings_Object extends Runway_Object {

}

?>
