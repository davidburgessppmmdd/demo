<?php 
// Translation strings
__('title', 'framework');
__('New Form', 'framework');
__('New Tab', 'framework');
__('New Container | invisible', 'framework');
__('Stars', 'framework');
?>