<?php 
// Translation strings
__('Theme Options', 'framework');
__('Contact Info', 'framework');
__('Social Media', 'framework');
__('Google Maps', 'framework');
?>