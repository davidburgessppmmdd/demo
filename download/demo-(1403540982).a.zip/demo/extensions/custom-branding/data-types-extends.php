<?php 
class Blogedit_type_usermeta extends Blogedit_type{

	public function save() {

	}

	public function get_value() {

    }
}

class Checkbox_bool_type_usermeta extends Checkbox_bool_type{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Checkbox_type_usermeta extends Checkbox_type{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Colorpicker_type_usermeta extends Colorpicker_type{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Fileupload_type_usermeta extends Fileupload_type{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Input_text_usermeta extends Input_text{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Multi_select_type_usermeta extends Multi_select_type{

	public function save() {
		
	}

	public function get_value() {
		out($this->field);
    }
}

class Radio_buttons_image_usermeta extends Radio_buttons_image{

	public function save() {
		
	}

	public function get_value() {

    }
}

class Textarea_type_usermeta extends Textarea_type{

	public function save() {
		
	}

	public function get_value() {

    }
}
?>