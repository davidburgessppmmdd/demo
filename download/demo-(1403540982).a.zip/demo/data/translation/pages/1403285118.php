<?php 
// Translation strings
__('Social Media', 'framework');
__('New Tab', 'framework');
__('Show Socials?', 'framework');
__('Facebook Profile URL', 'framework');
__('Twitter', 'framework');
__('Youtube', 'framework');
__('Google+', 'framework');
__('Linkedin', 'framework');
__('Instagram', 'framework');
__('Pinterest', 'framework');
__('Show In', 'framework');
__('Show Text?', 'framework');
?>