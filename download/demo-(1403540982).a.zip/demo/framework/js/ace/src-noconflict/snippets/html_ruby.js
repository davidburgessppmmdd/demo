ace.define('ace/snippets/html_ruby', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "html_ruby";

});
