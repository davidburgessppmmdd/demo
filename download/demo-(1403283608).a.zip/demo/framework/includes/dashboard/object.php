<?php

class Dashboard_Settings_Object extends Runway_Object{

	function __construct() {

	}
}

?>
