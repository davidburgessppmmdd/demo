
	<div class="changelog">
		<h3>Runway is an open source project.</h3>

		<!-- 
		<div class="feature-section images-stagger-right">
			<img src="http://placehold.it/350x350" class="image-30">
			<img src="http://placehold.it/350x350" class="image-30">
			<p>Be a part of the community and help contribute with your ideas and feedback.</p>
			
			<h4>???</h4>
			<p>???</p> 
		</div>
		-->

		<div class="feature-section">
			<p>Be a part of the community and help contribute with your ideas and feedback.</p>			
		</div>

	</div>
