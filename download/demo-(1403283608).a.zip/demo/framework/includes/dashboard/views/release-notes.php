
	<div class="changelog">
		<ul class="release-list">
			<li>
				<h3>Beta 1</h3>
				<p>
					<strong>Version 0.1</strong>
					- Core functionality created.
					<!-- For more information, see <a href="http://runwaywp.com/release-notes/version-0-1">the release notes</a>. -->
				</p>
			</li>
		</ul>
	</div>
