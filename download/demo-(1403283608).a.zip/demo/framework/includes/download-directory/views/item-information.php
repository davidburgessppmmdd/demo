<?php if ( $_GET['TB_iframe'] == 'true' ) { ?>
	<style type="text/css">

		#adminmenuwrap, #adminmenuback, #footer, #wpadminbar {
			display: none;
		}

		#wpcontent {
			margin: 0;
		}

	</style>

	<?php } ?>
